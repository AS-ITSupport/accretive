; $Id: README.txt,v 1.1.2.2 2009/07/23 20:36:16 kiam Exp $

This is the directory where you can place the files which define your custom
meta tags.